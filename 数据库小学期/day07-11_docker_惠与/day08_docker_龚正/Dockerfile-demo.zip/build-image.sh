#!/bin/bash

echo ""

echo -e "\nbuild app image\n"
sudo docker build   -t hpe_app_image .

echo ""
