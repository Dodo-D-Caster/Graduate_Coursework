#!/bin/sh
echo "hello :"
echo $APP_NAME